<?php

 require_once ('loader.php');

 $fun->do_contact();
 
 show('Pages/Contact/index');

?>