<?php

 require_once ('loader.php');
 session_destroy();
 redirect(['action' => '']);

?>