<?php /* Smarty version Smarty-3.1.21-dev, created on 2019-11-28 14:23:39
         compiled from "C:\wamp64\www\webroot\template\main\Installer\index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:13140393015ddfd86b43e356-56722858%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '519eab61e39ba1ded03110b8231caa99227fe26b' => 
    array (
      0 => 'C:\\wamp64\\www\\webroot\\template\\main\\Installer\\index.tpl',
      1 => 1547108982,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13140393015ddfd86b43e356-56722858',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'msg' => 0,
    'build' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5ddfd86b7a6034_89673825',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ddfd86b7a6034_89673825')) {function content_5ddfd86b7a6034_89673825($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ('../Installer/header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


    <title>Welcome to installation</title>

  <div class="container">
    <div class="card card-login mx-auto mt-5">
      <div class="card-header">Welcome to installation!</div>
      <div class="card-body"><?php echo $_smarty_tpl->tpl_vars['msg']->value;?>

        <form method="post" action="database">

        <?php if ($_smarty_tpl->tpl_vars['build']->value) {?>
         <button class="btn btn-primary btn-block" type="submit">Install</button>
        <?php }?>
        
        <br>
      <div style="text-align: center">
          <p><a target="_blank" href="//codsem.com">By Codesem</a></p>
          </div>
        </form>
      </div>
    </div>
  </div><?php }} ?>
