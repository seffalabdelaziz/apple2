<?php /* Smarty version Smarty-3.1.21-dev, created on 2019-11-28 14:23:39
         compiled from "C:\wamp64\www\webroot\template\main\Installer\header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:12571158965ddfd86b8c0d46-80015610%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0bb5fef6e4b45c288d7f803c4606dbfb9545b22f' => 
    array (
      0 => 'C:\\wamp64\\www\\webroot\\template\\main\\Installer\\header.tpl',
      1 => 1547108982,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12571158965ddfd86b8c0d46-80015610',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'THEME' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5ddfd86b8cd9f0_67003681',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ddfd86b8cd9f0_67003681')) {function content_5ddfd86b8cd9f0_67003681($_smarty_tpl) {?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="../template/<?php echo $_smarty_tpl->tpl_vars['THEME']->value;?>
/Assets/installer/vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="../template/<?php echo $_smarty_tpl->tpl_vars['THEME']->value;?>
/Assets/installer/vendor/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="../template/<?php echo $_smarty_tpl->tpl_vars['THEME']->value;?>
/Assets/installer/css/sb-admin.css">

</head>
<body class="bg-dark"><?php }} ?>
