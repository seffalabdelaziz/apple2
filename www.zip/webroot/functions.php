<?php

 require_once "loader.php";

 $smart->sign_deposits();
 
 secure_role();
 
?>