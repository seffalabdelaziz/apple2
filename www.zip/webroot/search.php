<?php

 require_once ('loader.php');

 $fun->do_search();

 show('Home/search');

?>