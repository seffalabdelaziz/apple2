<?php /* Smarty version Smarty-3.1.21-dev, created on 2019-11-28 14:23:39
         compiled from "C:\wamp64\www\webroot\template\main\Pages\404\index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:6640146695ddfd86b953420-48780727%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f5c473ab666a51c6e6c71380a2bd29f8af278166' => 
    array (
      0 => 'C:\\wamp64\\www\\webroot\\template\\main\\Pages\\404\\index.tpl',
      1 => 1547108982,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6640146695ddfd86b953420-48780727',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'background_image' => 0,
    '_ERROR_404' => 0,
    'HOST' => 0,
    '_HOME' => 0,
    '_ERROR' => 0,
    '_NOT_FOUND' => 0,
    '__NOT_FOUND' => 0,
    '_SEARCH_YOUR_ITEMS' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5ddfd86b99a9f8_99383694',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ddfd86b99a9f8_99383694')) {function content_5ddfd86b99a9f8_99383694($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate (((string)$_smarty_tpl->tpl_vars['TMP']->value)."/Layout/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


   <!-- PAGE PROMO START HERE -->
    <div class="promo-area overly-bg" data-stellar-background-ratio=".9" style="background-image: url(<?php echo $_smarty_tpl->tpl_vars['background_image']->value;?>
)">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="promo-text">
                        <h4><?php echo $_smarty_tpl->tpl_vars['_ERROR_404']->value;?>
</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- PAGE PROMO END HERE -->

    <!-- BREADCRUMB START HERE -->
    <div class="about-breadcrumb">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['_HOME']->value;?>
</a>
                        </li>
                        <li class="breadcrumb-item"><a href="#"><?php echo $_smarty_tpl->tpl_vars['_ERROR']->value;?>
</a>
                        </li>
                        <li class="breadcrumb-item active"><?php echo $_smarty_tpl->tpl_vars['_ERROR_404']->value;?>
</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <!-- BREADCRUMB END HERE -->

    <!-- CONTACT AREA START HERE -->
    <main class="error-area main-content">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="error-wrap">
                        <h3 class="error-heading"><?php echo $_smarty_tpl->tpl_vars['_NOT_FOUND']->value;?>
</h3><hr>
                        <p><?php echo $_smarty_tpl->tpl_vars['__NOT_FOUND']->value;?>
</p>
                        <form action="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
search" class="error-form">
                            <input type="text" placeholder="<?php echo $_smarty_tpl->tpl_vars['_SEARCH_YOUR_ITEMS']->value;?>
">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <!-- CONTACT AREA END HERE -->

<?php echo $_smarty_tpl->getSubTemplate (((string)$_smarty_tpl->tpl_vars['TMP']->value)."/Layout/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
<?php }} ?>
