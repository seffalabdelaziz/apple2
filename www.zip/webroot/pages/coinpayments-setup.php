<?php

 require_once (dirname(dirname(__FILE__)).'/loader.php');

 show('Pages/Help/coinpayments-setup');

?>