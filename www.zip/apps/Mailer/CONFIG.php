
<?php

$mail_option = 'php_mail';

$mail_username = '';

$mail_host = '';

$mail_port = '';

$mail_ssluse = 'tls';

$mail_pass = '';
