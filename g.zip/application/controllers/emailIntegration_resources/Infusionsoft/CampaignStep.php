<?php
class Infusionsoft_CampaignStep extends Infusionsoft_Generated_CampaignStep{	
    public function __construct($id = null, $app = null){
    	parent::__construct($id, $app);    	    	
    }
}

