<?php
class Infusionsoft_CProgram extends Infusionsoft_Generated_CProgram{	
    public function __construct($id = null, $app = null){
    	parent::__construct($id, $app);    	    	
    }
}

