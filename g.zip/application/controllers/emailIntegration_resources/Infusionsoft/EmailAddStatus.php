<?php

class Infusionsoft_EmailAddStatus extends Infusionsoft_Generated_EmailAddStatus{
    public function __construct($id = null, $app = null){
    	parent::__construct($id, $app);    	    	
    }
}

