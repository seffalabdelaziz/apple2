<?php
/**
 * Created by PhpStorm.
 * User: joey
 * Date: 6/19/2015
 * Time: 9:57 PM
 */

class Infusionsoft_CacheProvider implements Infusionsoft_TokenStorageProvider  {
    public function saveTokens($appDomainName, $accessToken, $refreshToken, $expiresIn){

    }

    public function getTokens($appDomainDomain){

    }

    public function getFirstAppName(){

    }
}